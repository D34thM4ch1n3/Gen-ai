import os
import sys
import json
import requests

def load_code(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def ask_llm(prompt, model_url="http://localhost:1234/v1/chat/completions"):
    headers = {"Content-Type": "application/json"}
    data = {
        "messages": [
            {"role": "system", "content": "You are a helpful code explainer. Be clear and concise."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 500,
        "stream": False
    }
    response = requests.post(model_url, headers=headers, json=data)
    return response.json()["choices"][0]["message"]["content"]

def main():
    if len(sys.argv) < 2:
        print("Usage: python code_explainer.py <file.py>")
        return
    file_path = sys.argv[1]
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return
    code = load_code(file_path)
    question = input("Ask something about the code: ")
    prompt = f"Here is the code:
{code}

My question: {question}"
    answer = ask_llm(prompt)
    print("\nExplanation:\n", answer)

if __name__ == "__main__":
    main()
