# AI Code Explainer (Offline, Local LLM)

This tool lets you explain code using a locally hosted LLM (like Mistral via LM Studio).

## How to Use

1. Start your LM Studio local server (default: http://localhost:1234).
2. Place a code file in the folder (e.g., example.py).
3. Run:
   ```bash
   python code_explainer.py example.py
   ```
4. Ask any question about the code.

## Requirements

- Python 3.8+
- LM Studio with local model (e.g. Mistral 7B)
- Install dependencies:
   ```
   pip install -r requirements.txt
   ```
